.. _general_examples:

Examples
========

Introductory examples.
